CREATE DATABASE person;

use person;

CREATE TABLE person (
	PersonID SERIAL PRIMARY KEY,
	Firstname VARCHAR(30) NOT NULL,
	Lastname VARCHAR(30) NOT NULL
);
