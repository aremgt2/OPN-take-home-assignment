# Takehome assigment 2020
Submission date: 20nd of December.

The Takehome description has been moved to [Google Drive](https://docs.google.com/document/d/1QjqNJ3KrIFw_DE89iEDiiNO6LLsyFLePG_cPEc-4r7M/edit?usp=sharing).
