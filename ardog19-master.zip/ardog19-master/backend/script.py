from flask import Flask, request, json
import mysql.connector
import collections

app = Flask(__name__, template_folder = 'html/')
#post
@app.route('/person', methods = ['POST'])
def person():
    firstname = request.form.get('firstname')
    lastname = request.form.get('lastname')

    mydb = connect()

    mycursor = mydb.cursor()

    mycursor.execute("INSERT INTO person (Firstname, Lastname) VALUES ('"+firstname+"', '"+lastname+"')")
    mydb.commit()
    mycursor.close()
    return '', 200

#get
@app.route('/persons', methods = ['GET'])
def persons():
    personList = []
    mydb = connect()
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM person")
    result = mycursor.fetchall()
    for row in result:
       data = collections.OrderedDict()
       data['PersonID'] = row[0]
       data['Firstname'] = row[1]
       data['Lastname'] = row[2]
       personList.append(data)
    mycursor.close()
    return json.dumps(personList), 200

def connect():
    mydb = mysql.connector.connect(host="database", user="root", database='person')
    return mydb

if(__name__ == '__main__'):
    app.run(host = '0.0.0.0')